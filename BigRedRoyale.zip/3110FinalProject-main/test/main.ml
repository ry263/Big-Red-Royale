open OUnit2

let game_tests = [
  "Testing OUNITs" >:: fun _ -> assert_equal "Hi" "Hi"
]
let tests =
  "test suite for game"
  >::: List.flatten [ game_tests ]

let _ = OUnit2.run_test_tt_main tests