open CharacterTypes
open Sdl
open Location

let mid_y = 0.
let mid_x = 0.
let top_right: location= (30.5,43.5)
let top_left: location = (-30.5,43.5)
let up_mid_right: location = (30.5, 5.)
let up_mid_left: location = (-30.5, 5.)
let down_mid_right: location = (30.5, -5.)
let down_mid_left: location = (-30.5, -5.)
let bot_right: location = (30.5, -43.5)
let bot_left: location = (-30.5, -43.5)

let player_base = (0., -45.)
let computer_base = (0., 45.)

let left_waypoints = [bot_left; down_mid_left; up_mid_left; top_left]
let right_waypoints = [bot_right; down_mid_right; up_mid_right; top_right]
let waypoints = [ 
  top_right; 
  top_left;
  up_mid_right;
  up_mid_left;
  down_mid_right;
  down_mid_left;
  bot_right;
  bot_left;
  player_base;
  computer_base
]

type character = {
  id: int; 
  position: location;
  health: float;
  max_health: float;
  movement_speed: float;
  perception_range: float;
  attack_power: float;
  attack_speed: int;
  attack_range: float;
  asset_name: string;
  size: location;
  animating: bool;
  characterType: characterType;
  target: int option;
} and characterType = 
  | Student
  | President of President.t
  | Camel
  | Chad 
  | Base

let new_character id position characterType = 
  let information = match characterType with 
   | Base -> Base.typeInformation
   | Student -> Student.typeInformation
   | President _ -> President.typeInformation
   | Chad -> Chad.typeInformation
   | Camel -> Camel.typeInformation
  in 
  {
  id=id;
  position=position;
  health=information.starting_health;
  max_health=information.starting_health;
  movement_speed=information.movement_speed;
  perception_range=information.perception_range;
  attack_power=information.attack_power;
  attack_speed=information.attack_speed;
  attack_range=information.attack_range;
  asset_name=information.asset_name;
  size=(information.width, information.height);
  animating=false;
  characterType=characterType;
  target=None;
}

let new_base id position = new_character id position Base
let new_student id position = new_character id position Student
let new_president id position = new_character id position (President President.init)
let new_chad id position = new_character id position Chad
let new_camel id position = new_character id position Camel

type characterState = | Rest | Move | Attack

type board = {
  opponents: character list;
  players: character list;
  entities: int;
}

(* MARK: Targeting *)
let yDiff character loc = 
  let (_, charY) = character.position in 
  let (_, locY) = loc in
  (locY -. charY)

(*[character_loop] If character is of type Base, just return character. Else, if the character is 
  on their own side of the board(i.e. if the yDiff between character and base is less than a
  certain number), then actively seek out characters to pathfind to. Otherwise, directly pathfind 
  to the next waypoint.*)

let rec get_char id = function 
| [] -> None 
| h :: t -> if h.id = id then Some h else get_char id t 

let target_character character opponents = 
  let rec target_helper character opponents (closest: character option) = 
    match opponents with 
    | [] -> closest
    | h :: t -> 
      let dist = Location.dist h.position character.position in 
      if dist <= character.perception_range then 
        match closest with 
        | None -> target_helper character t (Some h)
        | Some v -> if dist < Location.dist character.position v.position then target_helper character t (Some h)
          else target_helper character t (Some v)
      else 
        target_helper character t closest
    in 
  target_helper character opponents None

let next_waypoint (character: character) is_player = 
  let rec get_closest_vertical_waypoint pos is_player  =
  function
  | [] -> if is_player then computer_base else player_base
  (* | h :: [] -> let base = if is_player then computer_base else player_base in 
          let baseDist = Location.dist character.position base in
          if baseDist <= character.perception_range || baseDist <= Location.dist character.position h 
            (* (let dy = yDiff character h in dy < 3. || dy > -3.) *)
            then 
            base 
          else h *)
  | h :: t -> 
    let direction = if is_player then 1. else -1. in 
    let (_, charY) = pos in 
    let (_, wapY) = h in 
    if charY *. direction < wapY *. direction then h else get_closest_vertical_waypoint pos is_player t 
  in 
  let x, _ = character.position in 
  if x <= 0. then 
    get_closest_vertical_waypoint character.position is_player (if is_player then left_waypoints else List.rev left_waypoints)
  else 
    get_closest_vertical_waypoint character.position is_player (if is_player then right_waypoints else List.rev right_waypoints)

(* let move_towards_by character target length = { character with position= Location.project character.position target length }
let move_towards character (target:location) dt = move_towards_by character target (character.movement_speed *.  dt)  *)



let move_towards character target dt = Location.project character.position target (character.movement_speed *. dt)
let attack_move character target dt = 
  if Location.dist character.position target <= character.attack_range then character.position
  else move_towards character target dt

let rec character_target_loop (board: board) (is_player: bool) (character: character) (dt: float) : (character * Location.t) = 
  if character.characterType = Base then (character, character.position)
  else 
    (**
    If current target is entity -> check if it is close enough
      If so then continue
      If not then Retarget -> 
    If not then Retarget -> 
      iterate thru opponents and find closest one
        target if within perception
    
    If target is entity go to point
      else look for waypoints and go to next one
  *)
  let opponents = (if is_player then board.opponents else board.players) in 
  match character.target with 
  | Some i -> (
    match get_char i opponents with 
    | None -> character_target_loop board is_player { character with target = None } dt
    | Some c -> (character, attack_move character c.position dt))
  | None -> 
    match target_character character opponents with 
    | None -> 
      let waypoint = next_waypoint character is_player in 
      (character, move_towards character waypoint dt)
    | Some c -> (character, attack_move character c.position dt)




  (* let waypoint = 
    match character.target with 
    | None -> match target character opponents with 
        | None -> next_waypoint character is_player
        | Some i -> 
            (match get_char i with 
            | None -> failwith "id problems"
            | Some h -> h.position)
    | Some i -> 
      (match get_char i with 
        | None -> character_target_loop board is_player { character with target = None }
        | Some h -> h.position
      )
    in 
    (character, waypoint) *)

  (* let character = 
    match character.target with 
  | None -> character
  | Some i -> (* check if still valid *)
    match get_char i opponents with 
    | None -> character_target_loop board is_player { character with target = None } dt
    | Some h -> if Location.dist h.position character.position < character.perception_range then character
      else 
        match target character opponents with 
        | None -> character
        | Some i -> { character with target = Some i.id }
    in 
    match character.target with 
    | Some i -> 
      (match get_char i opponents with
      | None -> failwith "Character was deleted??"
      | Some h -> if distance character.position h.position <= h.attack_range then character
                  else move_towards character h.position dt)
    | None -> 
      let waypoint = next_waypoint character is_player in 
      if waypoint = (if is_player then computer_base else player_base) then
        let _ = print_endline "ollo" in 
        (if distance character.position waypoint <= character.attack_range then character
        else move_towards character waypoint dt)
      else 
        let dist = distance character.position waypoint in 
        if dist < character.movement_speed then 
          let _ = print_endline "hello" in 
          let character = move_towards_by character waypoint 0.001 in 
          character 
        else let _ = print_endline "alla" in move_towards character waypoint dt *)

  
    

    (* let waypoint = next_waypoint character is_player in 
    let mv = move_towards character waypoint dt in 
    (character, mv) *)
    (* if Location.dist waypoint character.position > character.movement_speed *. dt then
      (character, Location.project character.position waypoint (character.movement_speed *. dt))
    else 
      (character, waypoint) *)



  (* if character.characterType = Base then character
  else 
    character *)
    (* move_towards character (next_waypoint character is_player) dt *)


(*   
  if character.characterType = Base then character
  else 
  let opponents = (if is_player then board.opponents else board.players) in 
  let character = 
    match character.target with 
  | None -> character
  | Some i -> (* check if still valid *)
    match get_char i opponents with 
    | None ->  character_loop board is_player { character with target = None } dt
    | Some h -> if Location.dist h.position character.position < character.perception_range then character
      else 
        match target character opponents with 
        | None -> character
        | Some i -> { character with target = Some i.id }
    in 
    match character.target with 
    | Some i -> 
      (match get_char i opponents with
      | None -> failwith "Character was deleted??"
      | Some h -> if distance character.position h.position <= h.attack_range then character
                  else move_towards character h.position dt)
    | None -> 
      let waypoint = next_waypoint character is_player in 
      if waypoint = (if is_player then computer_base else player_base) then
        let _ = print_endline "ollo" in 
        (if distance character.position waypoint <= character.attack_range then character
        else move_towards character waypoint dt)
      else 
        let dist = distance character.position waypoint in 
        if dist < character.movement_speed then 
          let _ = print_endline "hello" in 
          let character = move_towards_by character waypoint 0.001 in 
          character 
        else let _ = print_endline "alla" in move_towards character waypoint dt *)







  (* if character.characterType = Base then character else 
    if character.animating then 
      character
    else
      if (yDiff character (get_base (if is_player then board.opponents else board.players)).position) < 40. then
        let result = target character (if is_player then board.opponents else board.players) 
          (get_base (if is_player then board.opponents else board.players)).position in
        match result with 
        (* Replace this with waypoints *)
        | None -> move_towards character 
          (get_new_loc character (get_next_waypoint character waypoints 0 
            (get_base_pos (if is_player then board.opponents else board.players)))
        | Some (_, _, l) -> move_towards character (get_new_loc character l)  
      else move_towards character 
        (get_new_loc character (get_next_waypoint character waypoints 0 
          (get_base_pos (if is_player then board.opponents else board.players)))
      ahhhh still have to use waypoints *)