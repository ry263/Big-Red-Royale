open Location
type location = Location.t

type characterInformation = {
  starting_health: float;
  movement_speed: float;
  perception_range: float;
  attack_power: float;
  attack_speed: int;
  attack_range: float;
  asset_name: string;
  width: float;
  height: float;
}

module Base = struct
  let typeInformation: characterInformation = {
    starting_health= 1000.;
    movement_speed= 0.;
    perception_range= 10.;
    attack_power= 10.;
    attack_speed= 2;
    attack_range=10.;
    asset_name= "base";
    width=5.;
    height=5.;
  }
  let attack () = ()
end

module Student = struct
  let typeInformation: characterInformation = {
    starting_health= 100.;
    movement_speed= 3.;
    perception_range= 15.;
    attack_power= 2.;
    attack_speed= 2;
    attack_range=2.;
    asset_name= "student";
    width=1.;
    height=1.;
  }
  let price = 1
  let attack = Base.attack
end

module President = struct
  type t = {
    spell_cool_down: int;
  }
  let typeInformation: characterInformation = {
    starting_health= 50.;
    movement_speed= 3.;
    perception_range= 15.;
    attack_power= 2.;
    attack_speed= 4;
    attack_range=5.;
    asset_name= "president";
    width=1.;
    height=1.;
  }
  let price = 4
  let attack = Base.attack
  let init = {
    spell_cool_down = 0;
  }
end

module Chad = struct
  let typeInformation: characterInformation = {
    starting_health= 200.;
    movement_speed= 5.;
    perception_range= 15.;
    attack_power= 5.;
    attack_speed= 1;
    attack_range=1.;
    asset_name= "chad";
    width=1.;
    height=1.;
  }
  let price = 3
  let attack = Base.attack
end

module Camel = struct
  let typeInformation: characterInformation = {
    starting_health= 400.;
    movement_speed= 1.;
    perception_range= 15.;
    attack_power= 10.;
    attack_speed= 1;
    attack_range=1.;
    asset_name= "camel";
    width=1.;
    height=1.;
  }
  let price = 6
  let attack = Base.attack
end

type characterOptions = | Base | Student | President | Chad | Camel

let price = function   
| Camel -> Camel.price
| President -> President.price
| Chad -> Chad.price
| Student -> Student.price
| Base -> failwith "Cannot be purchased" 