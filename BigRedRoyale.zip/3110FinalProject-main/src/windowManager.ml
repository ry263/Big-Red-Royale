open Screens
open Sound
open Sdl

let rec run_window (window_type: Screens.screen_type) = match window_type with 
| Game -> 
  let (window, state, sprites) = GameScreen.init() in
  GameScreen.main_loop window state sprites (Timer.get_ticks()) switch_window
| Ex ->
  let (window, state, sprites) = Ex.init() in
  Ex.main_loop window state sprites (Timer.get_ticks()) switch_window
| Home ->
  let (window, state, sprites) = HomeScreen.init() in
  Sound.play_audio;
  HomeScreen.main_loop window state sprites (Timer.get_ticks()) switch_window 
| Deck -> 
  let (window, state, sprites) = DeckScreen.init() in
  DeckScreen.main_loop window state sprites (Timer.get_ticks()) switch_window
| Info -> 
  let (window, state, sprites) = InfoScreen.init() in
  InfoScreen.main_loop window state sprites (Timer.get_ticks()) switch_window
  and switch_window (state: Screens.state_change) = match state with
| NoChanges -> () 
| Game -> Sdl.quit(); run_window Game
| Home -> Sdl.quit(); run_window Home
| Ex -> Sdl.quit(); run_window Ex
| Deck -> Sdl.quit(); run_window Deck
| Info -> Sdl.quit(); run_window Info