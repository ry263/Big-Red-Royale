open Sdl
open Sdlevent
open GameManager
open Location
open SpriteManager

type state_change = | NoChanges | Home | Game | Ex | Deck | Info

type screen_type = | Home | Game | Ex | Deck | Info

type window_manager = state_change -> unit

module type Screen = sig
  type t
  val init: unit -> (Sdlwindow.t * t * Sdltexture.t list)
  val main_loop: Sdlwindow.t -> t -> Sdltexture.t list -> int -> window_manager -> unit
end

let create_window (size: int * int) (title: string) = 
  let (width, height) = size in
  Sdl.init [`VIDEO; `JOYSTICK];
  at_exit print_newline;
    (* Window.create
      ~pos:(`centered, `centered)
      ~dims:(width, height)
      ~title:title
      ~flags:[Window.Resizable] *)
  Sdlwindow.create2
  ~title: title
  ~x: `undefined
  ~y: `undefined
  ~width: width
  ~height: height
  ~flags:[Sdlwindow.Resizable]

(* Refactor this–copied from Character.ml *)
let load_sprite renderer ~filename =
  let surf = Surface.load_bmp ~filename in
  let tex = Texture.create_from_surface renderer surf in
  Surface.free surf;
  (tex)
      
let rec load_sprites renderer = function
| [] -> []
| h :: t -> load_sprite renderer h :: load_sprites renderer t


let default_proc_events (event: Sdlevent.t) (window_manager: window_manager) : unit = 
  let result = match event with
  | KeyDown { keycode = Keycode.Q }
  | KeyDown { keycode = Keycode.Escape }
  | KeyDown { scancode = Scancode.ESCAPE }
  | Quit _ ->
      Sdl.quit ();
      let _ = exit 0 in
      NoChanges
  | Mouse_Button_Down { mb_state = Pressed; mb_x; mb_y } -> 
    (* check position is within one of the buttons *)
    (* call windowManager change window *)
    Game
  | e -> NoChanges      
  in window_manager result

let rec event_loop (proc_events: (Sdlevent.t -> window_manager -> unit)) (window_manager: window_manager) () =
  match Event.poll_event () with
  | None -> ()
  | Some ev ->
    proc_events ev window_manager;
      event_loop proc_events window_manager ()

module HomeScreen: Screen = struct
  type t = { rndr: Sdltype.renderer; size: (int * int); rect: int list list}
  let init () = 
    let size = (1024, 512) in
    let window = create_window size "Home" in 
    let rndr = Render.create_renderer window (-1) [Render.Accelerated] in
    Render.set_draw_color rndr (179,28,17) 255;
    let logo = "assets/misc_assets/cornellLogo.bmp" in 
    let title = "assets/misc_assets/BigRedRoyale.bmp" in
    let deck = "assets/misc_assets/deck.bmp" in
    let play = "assets/misc_assets/play.bmp" in

    (window, 
    { rndr=rndr; size=size; rect = [[250; 250; 387; 100]; [530;57;265;20]; [275;110;130;380];[275;110;619;380]]},
    (* width, height, x,y*)
    load_sprites rndr [logo;title;deck;play])

  let render t dt state sprites = 
    let rndr = state.rndr in 
    Render.clear rndr;
    Render.set_scale rndr (1.0, 1.0);
    let rec render_sprite sprites state n = 
      match sprites with
    | [] -> ()
    | h :: t -> 
      let lst = List.nth state.rect n in
      let width = List.hd lst in
      let height = List.nth lst 1 in 
      let src_rect = Rect.make4 0 0 width height in
      let dst_rect = Rect.make4 (List.nth lst 2) (List.nth lst 3) width height in
      Render.copy rndr
                ~texture:h
                ~src_rect
                ~dst_rect ();
                render_sprite t state (n+1) in render_sprite sprites state 0;
    Render.render_present rndr
  
  
let proc_events (event: Sdlevent.t) (window_manager: window_manager) : unit = 
  let result = match event with| KeyDown { keycode = Keycode.Q }
| KeyDown { keycode = Keycode.Escape }
| KeyDown { scancode = Scancode.ESCAPE }
| Quit _ ->
    Sdl.quit ();
    let _ = exit 0 in
    NoChanges
| Mouse_Button_Down ev -> 
  if ev.mb_x > 619 && ev.mb_x < 894 && ev.mb_y>380 && ev.mb_y<490 then Game 
  else if ev.mb_x <405 && ev.mb_x > 130 && ev.mb_y>380 && ev.mb_y<490 then Deck else NoChanges
  (* check position is within one of the buttons *)
  (* call windowManager change window *)
  
| e -> NoChanges     

in window_manager result
  let rec main_loop (window: Sdlwindow.t) (state: t) (sprites: Sdltexture.t list) (last: int) state_manager = 
    event_loop proc_events state_manager ();
    let t = Timer.get_ticks () in
    let dt = t - last in
    render t dt state sprites;
    main_loop window state sprites t state_manager
end

module GameScreen: Screen = struct

  let (boardWidth, boardHeight) = (640., 865.)
  let boardSize = (boardWidth, boardHeight)
  let (boardAssetWidth, boardAssetHeight) = (1080., 1510.) (* (925., 1250.) *)
  let boardAssetSize = (boardAssetWidth, boardAssetHeight)
  let (boardPaddingLeft, boardPaddingTop) = (80., 192.)
  let (boardPaddingRight, boardPaddingBottom) = (82., 80.)
  let (gameBoardWidth, gameBoardHeight) = ((boardAssetWidth, boardAssetHeight) |> 
    Location.(-.)) (boardPaddingRight +. boardPaddingLeft, boardPaddingBottom +. boardPaddingTop) (* Actual size of the board in game *)
  let gameBoardSize = (gameBoardWidth, gameBoardHeight)
  let (tileWidth, tileHeight) = (
    925. /. 18. *. boardWidth /. (gameBoardWidth),
  585. /. 14. *. boardHeight /. (gameBoardHeight))
  let tileSize = tileWidth, tileHeight

  type t = { 
    rndr: Sdltype.renderer; 
    size: (int * int); 
    gameState: GameManager.t; 
    background_asset: Sdltexture.t; 
    coin_assets: Sdltexture.t list;
    sprite_sheet: Sprite.sprite_sheet;
    background_bar: Sdltexture.t;
    money_bar: Sdltexture.t;
    full_health_bar: Sprite.t;
    current_health_bar: Sprite.t;
    current_money_bar: Sdltexture.t;
    request_money_bar: Sdltexture.t;
    target: Sprite.t;
    circle: Sprite.t;
  }
  let debug = true
  let load_coins renderer = 
    let rec load_coin n = 
      if n = 10 then load_sprite renderer ("assets/coins/" ^ (string_of_int n) ^ "©.bmp") :: [] else load_sprite renderer ("assets/coins/" ^ (string_of_int n) ^ "©.bmp") :: load_coin (n + 1)
    in load_coin 0

  let init () = 
    let size = (640, 1024) in
    let window = create_window size "Game" in 
    let rndr = Render.create_renderer window (-1) [Render.Accelerated] in
    let sprite_sheet = Sprite.sprite_sheet rndr in 
    let (emptyHealthbar, healthFrame) = Sprite.load_sprite rndr "assets/gameScreen/healthBar.bmp" in 
    Texture.set_blend_mode emptyHealthbar Add;
    Texture.set_alpha_mod emptyHealthbar 100;
    let (currentHealthbar, currentFrame) = Sprite.load_sprite rndr "assets/gameScreen/healthBar.bmp" in 
    (
      window, 
      { 
        rndr=rndr; 
        size=size; 
        gameState=GameManager.default_state ();
        background_asset=load_sprite rndr ("assets/gameScreen/BRRBackground.bmp");
        coin_assets=load_coins rndr;
        sprite_sheet=sprite_sheet;
        background_bar = load_sprite rndr "assets/gameScreen/deckBackground.bmp";
        money_bar=load_sprite rndr "assets/gameScreen/outline.bmp";
        current_money_bar=load_sprite rndr "assets/gameScreen/money.bmp";
        request_money_bar=load_sprite rndr "assets/gameScreen/purchaseMoney.bmp";
        full_health_bar=emptyHealthbar, healthFrame;
        current_health_bar=(currentHealthbar, currentFrame);
        target=Sprite.load_sprite rndr "assets/misc_assets/cornellLogo.bmp";
        circle=Sprite.load_sprite rndr "assets/misc_assets/circle.bmp";
      },
      [ ] 
    )
    let rec event_loop (state: t) (proc_events: (t -> Sdlevent.t -> window_manager -> t)) (window_manager: window_manager) () =
      match Event.poll_event () with
      | None -> state
      | Some ev ->
        let state = proc_events state ev window_manager in
          event_loop state proc_events window_manager ()


  let gui_to_board_asset (mb_x, mb_y) = (((((mb_x, mb_y) |> Location.from_int |> Location.(/.)) boardSize |> Location.( *. ) boardAssetSize |> Location.(-.)) (boardPaddingLeft, boardPaddingTop) |> Location.(/.)) gameBoardSize |> Location.(-)) 0.5 |> Location.( * ) 100. |> Location.( *. ) (1., -1.)
  
  let board_to_gui (x, y) = 
    let pos_in_asset = (x, y) |> Location.( *. ) (1., -1.) |> Location.(+) 50. |> Location.(/) 100. |> Location.( *. ) gameBoardSize |> Location.( +. ) (boardPaddingLeft, boardPaddingTop) in 
    (pos_in_asset |> Location.(/.)) boardAssetSize |> Location.( *. ) boardSize

  let board_to_gui_scale p = (p |> Location.( * ) 0.01 |> Location.( *. ) gameBoardSize |> Location.( *. ) boardSize |> Location.( /. )) boardAssetSize

  let proc_events (state: t) (event: Sdlevent.t) (window_manager: window_manager) : t = 
    match event with 
    | Mouse_Button_Down { mb_state = Pressed; mb_x; mb_y } -> 
      (* check position is within one of the buttons *)
      (* call windowManager change window *)
      let charType: CharacterTypes.characterOptions = Student in 
      let (x, y) = (mb_x, mb_y) |> gui_to_board_asset in 
      (* if x < -50. || x > 50. || y > 0. || y < -50. then state else *)
      {
        state with gameState = GameManager.add_request state.gameState  (Some (true, charType, (x, y)))
      }
    | _ ->
      let result = match event with
      | KeyDown { keycode = Keycode.Q }
      | KeyDown { keycode = Keycode.Escape }
      | KeyDown { scancode = Scancode.ESCAPE }
      | Quit _ ->
          Sdl.quit ();
          let _ = exit 0 in
          NoChanges
      | e -> NoChanges      
      in window_manager result;
      state

  let render t dt state sprites money = 
    let coin_rect_in = Rect.make4 0 0 620 40 in 

    let rndr = state.rndr in 
    Render.clear rndr;
    Render.set_scale rndr (1.0, 1.0);
    let render_at_position src_rect dst_rect texture = 
      Render.copy rndr
      ~texture:texture
      ~src_rect
      ~dst_rect (); 
    in 
    let (width, height) = state.size in 
    render_at_position (Rect.make4 0 0 (int_of_float boardAssetWidth) (int_of_float boardAssetHeight)) (Rect.make4 0 0 (int_of_float boardWidth) (int_of_float boardHeight)) state.background_asset;
    let rec render_characters (characters: (Character.character * CharacterTypes.location) list) is_user = 
      match characters with
        | [] -> ()
        | (h, location) :: t -> 
          let (sprite, src) = (Sprite.get_texture h Rest state.sprite_sheet) in
          let spriteWidth, spriteHeight = (h.size |> Location.( *. ) tileSize) in 
          let (x, y): (int * int) = ((board_to_gui (h.position) |> Location.(-.)) (h.size |> Location.( * ) 0.5) |> Location.(-.)) (spriteWidth /. 2., spriteHeight /. 2.) |> Location.to_int in 

          if debug then 
            let circle, circlesrc = state.circle in 
            let r = (h.perception_range) in 
            let (r, _) = (r, r) |> board_to_gui_scale |> Location.to_int in 
            Texture.set_blend_mode circle Add; 
            Texture.set_color_mod circle (255, 255, 255);
            Texture.set_alpha_mod circle 10;
            render_at_position circlesrc (Rect.make4 (x + int_of_float (spriteWidth /. 2.) - r) (y + int_of_float (spriteHeight /. 2.) - r) (r * 2) (r * 2)) circle;

            let r = (h.attack_range) in 
            let (r, _) = (r, r) |> board_to_gui_scale |> Location.to_int in 
            Texture.set_blend_mode circle Add; 
            Texture.set_alpha_mod circle 255;
            Texture.set_color_mod circle (255, 0, 0);
            render_at_position circlesrc (Rect.make4 (x + int_of_float (spriteWidth /. 2.) - r) (y + int_of_float (spriteHeight /. 2.) - r) (r * 2) (r * 2)) circle


          else ();

            let dst_rect = Rect.make4 x y (int_of_float spriteWidth) (int_of_float spriteHeight) in
          render_at_position src dst_rect sprite;

          let healthWidth, healthHeight = ((50., 10.) |> Location.( *. ) (spriteWidth, spriteHeight) |> Location.(/.)) ((tileWidth, tileHeight) |> Location.( * ) 3.) |> Location.to_int in 
            (* render full *)
            let health, src = state.full_health_bar in 
            Texture.set_color_mod health (if is_user then (0, 0, 255) else (255, 155, 155));
            render_at_position src (Rect.make4 (x + int_of_float spriteWidth / 2 - healthWidth / 2) (y - 15) healthWidth healthHeight) health;
          if h.health < h.max_health then 

            let currentHealth, src = state.current_health_bar in 
            let pct = h.health /. h.max_health in 
            let color = (int_of_float (255. *. (1. -. pct)), int_of_float (255. *. pct), 0) in 
            let healthPCT = max (int_of_float (pct *. float_of_int healthWidth)) 0 in 
            Texture.set_color_mod currentHealth color;

            render_at_position src (Rect.make4 (x + int_of_float spriteWidth / 2 - healthWidth / 2) (y - 15) healthPCT healthHeight) currentHealth
          else ();
        render_characters t is_user 
      in 
      render_characters (GameManager.get_sprites state.gameState false) false;
      render_characters (GameManager.get_sprites state.gameState true) true;


    let target, targetsrc = state.target in 
    let target_out = Rect.make4 0 0 20 20 in 
    let rec draw_waypoints = function 
    | [] -> () 
    | h :: t -> 
      let locx, locy = (h |> board_to_gui |> Location.(-)) 10. |> Location.to_int  in
      render_at_position targetsrc { target_out with x = locx; y = locy } target;
      draw_waypoints t 
    in
    draw_waypoints Character.waypoints;
    (* drawing money to the screen *)
    let rec coin n coins =
      match coins with 
      | [] -> failwith "Invalid amount of money"
      | h :: t -> if n = 0 then h else coin (n - 1) t
    in
    (* drawing menu *)
    let padding = 10 in 
    let menuHeight = height - int_of_float boardHeight in 
    let rect = Rect.make4 0 0 620 200 in 
    let menuTop = int_of_float boardHeight in 
    let rect_out = Rect.make4 0 menuTop width menuHeight in 
    render_at_position rect rect_out state.background_bar;
    (* Money *)
    let request_cost = GameManager.current_request_cost state.gameState in 
    if request_cost <> 0 then 
      let rect_out = Rect.make4 padding (menuTop + padding) (int_of_float ((float_of_int 620) *. float_of_int request_cost /. 10.)) 40 in 
      render_at_position coin_rect_in rect_out state.request_money_bar;
    else ();
    let rect_out = Rect.make4 padding (menuTop + padding) (int_of_float ((float_of_int 620) *. money /. 10.)) 40 in 
    render_at_position rect rect_out state.current_money_bar;
    let rect_out = Rect.make4 padding (menuTop + padding) 620 40 in 
    render_at_position rect rect_out state.money_bar;

    let src_rect = if int_of_float money = 10 then Rect.make4 0 0 78 33 else Rect.make4 0 0 55 33 in
    let dst_rect = { src_rect with x = (int_of_float boardWidth) - padding - src_rect.w; y = padding } in
    render_at_position src_rect dst_rect (coin (int_of_float money) state.coin_assets); 

    Render.render_present rndr
  
  let rec main_loop (window: Sdlwindow.t) (state: t) (sprites: Sdltexture.t list) (last: int) state_manager = 
    let state = event_loop state proc_events state_manager () in 
    let t = Timer.get_ticks () in
    let dt = t - last in
    let state = {
      state with gameState = (GameManager.game_loop state.gameState (dt * 4))
    } in
    render t dt state sprites (GameManager.player_money state.gameState);
    main_loop window state sprites t state_manager
end

module Ex : Screen = struct
  type t = { rndr: Sdltype.renderer; size: (int * int) }
  let init () = 
    print_string "running ex";
    let size = (1024, 512) in
    let window = create_window size "Example" in 
    let rndr = Render.create_renderer window (-1) [Render.Accelerated] in
    (* let surf = Sdlwindow.get_surface window in
    let color = 0xb31c11_l in
    let width, height = Window.get_size window in 
    let rect = Sdlrect.make4  0 0 width height in
    Sdlsurface.fill_rect surf rect color;
    Sdlwindow.update_surface window; *)
    (window, 
    { rndr=rndr; size=size; },
    load_sprites rndr ["assets/misc assets/circle64.bmp"])
    let proc_events event : state_change = match event with
    | KeyDown { keycode = Keycode.Q }
    | KeyDown { keycode = Keycode.Escape }
    | KeyDown { scancode = Scancode.ESCAPE }
    | Quit _ ->
        Sdl.quit ();
        let _ = exit 0 in
        NoChanges
    | e -> NoChanges 
    let render t dt state sprites  =
      let src_rect = Rect.make4 0 0 64 64 in
      let dst_rect = Rect.make4 100 100 64 64 in
      let (_, height) = state.size in 
      let rndr = state.rndr in 
      let y = (t / 10) mod height in
      let dst_rect = { dst_rect with Rect.y = y } in
      Render.clear rndr;
      Render.set_scale rndr (1.0, 1.0);
      let rec draw_sprites = function 
      | [] -> ()
      | h :: t -> 
        begin 
        Render.copy rndr
        ~texture:h
        ~src_rect
        ~dst_rect ();
        draw_sprites t 
        end
      in draw_sprites sprites;

      Render.render_present rndr

    let rec main_loop (window: Sdlwindow.t) (state: t) (sprites: Sdltexture.t list) (last: int) state_manager =
      event_loop default_proc_events state_manager ();
      let t = Timer.get_ticks () in
      let dt = t - last in
      render t dt state sprites;
      main_loop window state sprites t state_manager
end 


module DeckScreen: Screen = struct
  type t = { rndr: Sdltype.renderer; size: (int * int); sprites: (Sdltexture.t*int list) list} 
  (* sprites contain the list of sprites to be rendered and their positions *)
  
  let init () = 
    let size = (1024, 512) in
    let window = create_window size "Deck" in 
    let rndr = Render.create_renderer window (-1) [Render.Accelerated] in
    Render.set_draw_color rndr (179,28,17) 255;
    let deck_bg = load_sprite rndr "assets/misc_assets/deckBackground.bmp" in
    (* let president = "assets/president/president.bmp" in
    let student = "assets/student/student.bmp" in
    let camel = "assets/camel/camel.bmp" in *)

    (window, 
    { rndr=rndr; size=size; sprites = [(deck_bg,[967;490;29;11])]},
    (* width, height, x,y *)
    [])

    let rec event_loop (state: t) (proc_events: (t -> Sdlevent.t -> window_manager -> t)) (window_manager: window_manager) () =
      match Event.poll_event () with
      | None -> state
      | Some ev ->
        let state = proc_events state ev window_manager in
          event_loop state proc_events window_manager ()


    let deck_position state = 
      let n = List.length state.sprites in 
      if n = 1 then [123;150;108;170] else if n = 2 then [123;150;238;170]
       else if n = 3 then [123;150;364;170]
       else []


    let proc_events (state: t) (event: Sdlevent.t) (window_manager: window_manager) : t = 
      match event with 
      | Mouse_Button_Down { mb_state = Pressed; mb_x; mb_y }  -> 
        (* if chad is clicked *)
        if mb_x > 594 && mb_x < 707 && mb_y>76 && mb_y<214 then let chad = "assets/chad/chad.bmp" in
        {state with sprites =  state.sprites @ [(load_sprite state.rndr chad,deck_position state)]}
        (* if president is clicked *)
        else if mb_x > 813 && mb_x < 922 && mb_y>87 && mb_y<226 then let president = "assets/president/president.bmp" in
        {state with sprites =  state.sprites @ [(load_sprite state.rndr president,deck_position state)]}
        (* if student is clicked *)
        else if mb_x > 597 && mb_x < 707 && mb_y>278 && mb_y<417 then let student = "assets/student/student.bmp" in
        {state with sprites =  state.sprites @ [(load_sprite state.rndr student,deck_position state)]}
        (* if camel is clicked *)
        else if mb_x > 813 && mb_x < 922 && mb_y>278 && mb_y<417 then let camel = "assets/camel/camel.bmp" in
        {state with sprites =  state.sprites @ [(load_sprite state.rndr camel,deck_position state)]}
        else state
      | _ -> 
     let result = match event with
      | KeyDown { keycode = Keycode.Q }
      | KeyDown { keycode = Keycode.Escape }
      | KeyDown { scancode = Scancode.ESCAPE }
      | Quit _ ->
          Sdl.quit ();
          let _ = exit 0 in
          NoChanges
      | KeyDown { keycode = Keycode.I } -> Info
      | e -> NoChanges
    in window_manager result; state

  let render t dt state  = 
    let rndr = state.rndr in 
    Render.clear rndr;
    Render.set_scale rndr (1.0, 1.0);
    let rec render_sprite sprites = 
      match sprites with
    | [] -> ()
    | h :: t -> 
      let (sprite,pos) = h in 
      let width = List.hd pos in
      let height = List.nth pos 1 in 
      let src_rect = Rect.make4 0 0 width height in
      let dst_rect = Rect.make4 (List.nth pos 2) (List.nth pos 3) width height in
      Render.copy rndr
                ~texture: sprite
                ~src_rect
                ~dst_rect ();
                render_sprite t in render_sprite state.sprites;
    Render.render_present rndr
  
  let rec main_loop (window: Sdlwindow.t) (state: t) (sprites: Sdltexture.t list) (last: int) state_manager = 
    let state = event_loop state proc_events state_manager () in 
    let t = Timer.get_ticks () in
    let dt = t - last in
    render t dt state ;
    main_loop window state sprites t state_manager
end


module InfoScreen: Screen = struct
  type t = { rndr: Sdltype.renderer; size: (int * int); rect: int list list; t_sprites: Sdltexture.t list}
  
  let init () = 
    let size = (1024, 512) in
    let window = create_window size "Info" in 
    let rndr = Render.create_renderer window (-1) [Render.Accelerated] in
    Render.set_draw_color rndr (179,28,17) 255;
    let info = load_sprite rndr "assets/misc_assets/infoscreen.bmp" in

    (window, 
    { rndr=rndr; size=size; rect = [[966;490;29;11]]; t_sprites = [info]},
    (* width, height, x,y *)
    [])

    let rec event_loop (state: t) (proc_events: (t -> Sdlevent.t -> window_manager -> t)) (window_manager: window_manager) () =
      match Event.poll_event () with
      | None -> state
      | Some ev ->
        let state = proc_events state ev window_manager in
          event_loop state proc_events window_manager ()
    let proc_events (state: t) (event: Sdlevent.t) (window_manager: window_manager) : t = 
     let result = match event with
      | KeyDown { keycode = Keycode.Q }
      | KeyDown { keycode = Keycode.Escape }
      | KeyDown { scancode = Scancode.ESCAPE }
      | Quit _ ->
          Sdl.quit ();
          let _ = exit 0 in
          NoChanges
      | KeyDown { scancode = Scancode.SPACE } -> Deck
      | e -> NoChanges
    in window_manager result; state

  let render t dt state sprites = 
    let rndr = state.rndr in 
    Render.clear rndr;
    Render.set_scale rndr (1.0, 1.0);
    let rec render_sprite sprites state n = 
      match sprites with
    | [] -> ()
    | h :: t -> 
      let lst = List.nth state.rect n in
      let width = List.hd lst in
      let height = List.nth lst 1 in 
      let src_rect = Rect.make4 0 0 width height in
      let dst_rect = Rect.make4 (List.nth lst 2) (List.nth lst 3) width height in
      Render.copy rndr
                ~texture:h
                ~src_rect
                ~dst_rect ();
                render_sprite t state (n+1) in render_sprite state.t_sprites state 0;
    Render.render_present rndr
  
  let rec main_loop (window: Sdlwindow.t) (state: t) (sprites: Sdltexture.t list) (last: int) state_manager = 
    let state = event_loop state proc_events state_manager () in 
    let t = Timer.get_ticks () in
    let dt = t - last in
    render t dt state sprites;
    main_loop window state sprites t state_manager
end
