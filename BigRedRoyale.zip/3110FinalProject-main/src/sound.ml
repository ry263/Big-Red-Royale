open Sdl

type audio_device = {
  wav_buf: Sdlaudio.audio_buffer;
  wav_len: int32;
  device_id: Sdlaudio.audio_device_id;
  wav_spec: Sdlaudio.audio_spec
}

let rec play_background_music wav_buf wav_len device_id wav_spec = 
  (* play audio *)
  Audio.queue_audio device_id wav_buf wav_len;
  Audio.unpause_audio_device device_id;

  (* keep application running long enough to hear the sound *)
  Timer.delay 9000;

  (* clean up *)
  Audio.close_audio_device device_id;
  Audio.free_audio_spec wav_spec;
  Audio.free_wav wav_buf;
  let _ = play_background_music wav_buf wav_len device_id wav_spec in ()

let play_audio =
  Sdl.init [`AUDIO];
 
  let wav_spec = Audio.new_audio_spec () in

  (* load WAV file *)
  let wav_buf, wav_len =
    Audio.load_wav "assets/misc_assets/menuMusic.wav" wav_spec in

  (* open audio device *)
  let device_id = Audio.open_audio_device_simple wav_spec in
  (* play audio *)
  Audio.queue_audio device_id wav_buf wav_len;
  Audio.unpause_audio_device device_id;
  ()