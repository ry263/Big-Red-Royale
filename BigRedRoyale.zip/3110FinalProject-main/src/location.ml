module Location = struct
  type t = float * float
  let length (x, y) = (x ** 2. +. y ** 2.) ** 0.5 
  let ( + ) s (lx, ly) = (lx +. s, ly +. s)
  let ( +. ) (lx, ly) (sx, sy) = (lx +. sx, ly +. sy)
  let ( * ) s (lx, ly) = (lx *. s, ly *. s)
  let ( *. ) (lx, ly) (sx, sy) = (lx *. sx, ly *. sy)
  let ( / ) s (lx, ly) = (lx /. s, ly /. s)
  let ( /. ) (lx, ly) (sx, sy) = (lx /. sx, ly /. sy)
  let ( - ) (lx, ly) s = (lx -. s, ly -. s)
  let ( -. ) (lx, ly) (rx, ry) = (lx -. rx, ly -. ry)
  let dist (p1: t) (p2: t) = let diff = p2 -. p1 in length diff

  let unitVector p = 
    (/) (length p) p 
  let project (p1: t) (p2: t) len = 
    let dst = dist p1 p2 in 
    if dst = 0. then p1 else 
    if dst <= len then p2
    else (p2 -. p1) |> ( / ) dst |> ( * ) len |> ( +. ) p1

  let to_int (x, y) = (int_of_float x, int_of_float y)
  let from_int (x, y) = float_of_int x, float_of_int y
end