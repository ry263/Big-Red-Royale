(** Authors: Noah Pikielny np299, Alice Sze ys788, Rachel263 *)

let hours_worked = 64