open Character
open Sdl
open Sdlevent

module Sprite = struct
  type t =  Sdltexture.t * Sdlrect.t

  let asset_name : (CharacterTypes.characterOptions -> string) = function
| Camel -> "camel"
| President -> "president"
| Chad -> "chad"
| Student -> "student"
| Base -> "base"
  let action_name = function 
  | Rest -> "rest"
  | Move -> "move"
  | Attack -> "attack"

  let sprite_name charType action = "assets/" ^ asset_name charType ^ "/" ^ action_name action ^ ".bmp"

  let load_sprite renderer ~filename =
    let surf = Surface.load_bmp ~filename in
    let (w, h) = (Surface.get_width surf, Surface.get_height surf) in 
    let rect = Rect.make4 0 0 w h in 
    let tex = Texture.create_from_surface renderer surf in
    Surface.free surf;
    (tex, rect)

  let chars: CharacterTypes.characterOptions list = [Student; Base]
  let actions = [Rest; Move; Attack]

  type sprite_sheet = (CharacterTypes.characterOptions * (Character.characterState * t) list) list
  let sprite_sheet renderer = 
    let rec get_character_sheet character actions = match actions with
    | [] -> []
    | h :: t -> let filename = sprite_name character h in
      (h, load_sprite renderer ~filename) :: get_character_sheet character t in
    let rec get_sheet = function
    | [] -> []
    | h :: t -> (h, get_character_sheet h actions) :: get_sheet t in
    get_sheet chars

    let get_texture (c: character) (a: characterState) (s: sprite_sheet) = 
      let rec get_action = function
      | [] -> raise Not_found
      | (action, asset) :: t -> if action = a then asset else get_action t in 
      let c: CharacterTypes.characterOptions = 
        match c.characterType with 
        | Camel -> Camel
        | President _ -> President
        | Chad -> Chad
        | Student -> Student 
        | Base -> Base
      in
      let rec get_character = function
        | [] -> raise Not_found
        | (character, sheet) :: t -> if character = c then get_action sheet else get_character t
      in get_character s
end