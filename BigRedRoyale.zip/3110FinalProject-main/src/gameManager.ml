open Character
open Sdl
open Random

module GameManager = struct
  type player = {
    money: float
  }

  type request = (bool * CharacterTypes.characterOptions * Location.Location.t) option

  type t = {
    board: Character.board;
    user: player;
    computer: player;
    user_request: request;
    computer_request: request;
  }
  let default_player () = { money = 0. }
  let default_state () = {
    board = {
      opponents = [new_base 0 (0., 40.)];
      players = [new_base 1 (0., -40.)];
      entities = 2;
    };
    user = default_player ();
    computer = default_player ();
    user_request = None;
    computer_request = None;
  }
  let edit_money amount is_user state = 
    if is_user then {
      state with user = {
        money = max (min (state.user.money +. amount) 10.) 0.;
      }
    }
    else {
      state with computer = {
        money = max (min (state.computer.money +. amount) 10.) 0.;
      }
    }

  let purchase character price is_user state = 
    let correct_money = edit_money (-1. *. float_of_int price) is_user state in 
    if is_user then 
      {
      correct_money with board = { 
        correct_money.board with
        players = character :: correct_money.board.players;
        entities=state.board.entities+1;
      };
      user_request = None;
    }
    else {
      correct_money with board = {
        correct_money.board with
        opponents = character :: correct_money.board.opponents;
        entities=state.board.entities+1;
      };
      computer_request = None;
    }

  let is_purchaseable is_user price state = 
    let balance = if is_user then state.user.money else state.computer.money in 
    int_of_float balance >= price

  let player_money state = state.user.money
  
  let print_player_count state = 
    let rec length lst acc = 
      match lst with 
      | [] -> 0
      | h :: t -> length t (acc + 1)
    in 
    print_int (length state.board.players 0)
  
  let add_request state (request: request) = 
    match request with 
    | None -> state
    | Some r -> let (is_user, _, _) = r in 
      if is_user then 
        { state with user_request = request }
      else 
        { state with computer_request = request }


  let process_purchase_request (purchase_request: request) state = 
    match purchase_request with
    | None -> state
    | Some (user, request, location) ->
      let price = CharacterTypes.price request in 
        if is_purchaseable user price state then 
          match request with 
          | Camel -> purchase (new_camel state.board.entities location) price user state 
          | President -> purchase (new_president state.board.entities location) price user state 
          | Chad -> purchase (new_chad state.board.entities location) price user state 
          | Student -> purchase (new_student state.board.entities location) price user state 
          | Base -> failwith "Unpurchaseable entity"
        else state

  let rec update_characters board dt: (character list * character list) = 
    let rec targeting_characters is_user = 
      function 
      | [] -> []
      | h :: t -> Character.character_target_loop board is_user h dt :: targeting_characters is_user t
    in
    let players = targeting_characters true board.players in 
    let computers = targeting_characters false board.opponents in 
    let stripper = List.map (fun (c, l) -> { c with position = l } ) in 
    (stripper players, stripper computers)
  let game_loop state dt = 
    let amnt = (float_of_int dt) /. 2400. 
    in 
    let next_state = edit_money amnt false (edit_money amnt true state) in
    let state = process_purchase_request 
      state.computer_request 
      (process_purchase_request state.user_request next_state) in 
    let state = 
      if state.computer.money >= 1. then process_purchase_request (Some (false, Student, ((Random.float 100.) -. 50., (Random.float 50.)))) state
      else state in 


    let (players_updated, opponents_updated) = update_characters state.board amnt in 
    {
      state with board = {
        state.board with 
        opponents = List.filter (fun c -> c.health > 0.) opponents_updated;
        players = List.filter (fun c -> c.health > 0.) players_updated
      }
    }

    (* state *)

    (* let players_updated = update_characters state.board.players state.board true in 
    let opponents_updated = update_characters state.board.opponents state.board false in 
    {
      state with board={
        opponents=opponents_updated;
        players=players_updated;
      };
      user={
        state.user with characters=players_updated
      };
      computer={
        state.computer with characters=opponents_updated
      }
    } *)
    (* state *)

  let get_sprites state is_user = 
    let rec get_sprite = function 
      | [] -> []
      | h :: t -> (h, h.position) :: get_sprite t
    in get_sprite (if is_user then state.board.players else state.board.opponents)

  let current_request_cost state = 
    match state.user_request with 
    | None -> 0
    | Some (_, characterOption, _) -> CharacterTypes.price characterOption

end